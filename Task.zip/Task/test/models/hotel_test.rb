require 'test_helper'

class HotelTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end

  test "hotel attributes must not be empty" do

    hotel = hotel.new
    assert hotel.invalid?
    assert hotel.errors[:title].any?
    assert hotel.errors[:description].any?
    assert hotel.errors[:price].any?
    assert hotel.errors[:photo].any?
    assert hotel.errors[:breakfast].any?
    assert hotel.errors[:star].any?
    assert hotel.errors[:adress].any?

  end
  test "hotel price must be positive" do
# цена товара должна быть положительной
    product = hotel.new(title: "My Book Title",
                          description: "yyy",
                          photo:     "zzz.jpg",
                          breakfast: "yes",
                          star: "3",
                          adres: "Lviv")
    product.price = -1
    assert hotel.invalid?
    assert_equal ["must be greater than or equal to 0.01"],
                 hotel.errors[:price]
    # должна быть больше или равна 0.01
    hotel.price = 0
    assert hotel.invalid?
    assert_equal ["must be greater than or equal to 0.01"],
                 hotel.errors[:price]
    hotel.price = 1
    assert hotel.valid?
  end

  test "photo" do
    ok = %w{ fred.gif fred.jpg fred.png FRED.JPG FRED.Jpg
             http://a.b.c/x/y/z/fred.gif }
    bad = %w{ fred.doc fred.gif/more fred.gif.more }

    ok.each do |name|
      assert new_photo(name).valid?, "#{name} should be valid"
    end

    bad.each do |name|
      assert new_photo(name).invalid?, "#{name} shouldn't be valid"
    end
  end

  test "photo is not valid without a unique title" do
    product = hotel.new(title: "My Book Title",
                        description: "yyy",
                        photo:     "zzz.jpg",
                        breakfast: "yes",
                        star: "3",
                        adres: "Lviv")
    product.price = -1
    assert hotel.invalid?
    assert_equal ["must be greater than or equal to 0.01"],
                 hotel.errors[:price]
    photo = Hotel.new(title: "My Book Title",
                      description: "yyy",
                      photo:     "zzz.jpg",
                      breakfast: "yes",
                      star: "3",
                      adres: "Lviv")
    assert photo.invalid?
    assert_equal ["has already been taken"], photo.errors[:title]
  end
end
