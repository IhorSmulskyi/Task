require 'test_helper'

class HotelsHelperTest < ActionView::TestCase
end
