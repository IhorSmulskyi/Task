require 'test_helper'

class HotelsControllerTest < ActionController::TestCase
  setup do
    @hotel = hotels(:one)
    @update = {
        title: 'Hotel Aurora',
        description: ' very nice hotel!',
        photo: '77.jpg',
        breakfast:yes,
        star:5,
        adress:Lviv Franka 44,
        price: 19.95
    }
  end

  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:hotels)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create hotel" do
    assert_difference('Hotel.count') do
      post :create, hotel: { adress: @hotel.adress, breakfast: @hotel.breakfast, description: @hotel.description, photo: @hotel.photo, price: @hotel.price, star: @hotel.star, title: @hotel.title }
    end

    assert_redirected_to hotel_path(assigns(:hotel))
  end

  test "should show hotel" do
    get :show, id: @hotel
    assert_response :success
  end

  test "should get edit" do
    get :edit, id: @hotel
    assert_response :success
  end

  test "should update hotel" do
    patch :update, id: @hotel, hotel: { adress: @hotel.adress, breakfast: @hotel.breakfast, description: @hotel.description, photo: @hotel.photo, price: @hotel.price, star: @hotel.star, title: @hotel.title }
    assert_redirected_to hotel_path(assigns(:hotel))
  end

  test "should destroy hotel" do
    assert_difference('Hotel.count', -1) do
      delete :destroy, id: @hotel
    end

    assert_redirected_to hotels_path
  end
end
