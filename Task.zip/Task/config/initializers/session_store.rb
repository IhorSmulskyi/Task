# Be sure to restart your server when you modify this file.

Task::Application.config.session_store :cookie_store, key: '_Task_session'
