class CreateHotels < ActiveRecord::Migration
  def change
    create_table :hotels do |t|
      t.string :photo
      t.string :title
      t.text :description
      t.string :breakfast
      t.string :star
      t.text :adress
      t.decimal :price

      t.timestamps
    end
  end
end
