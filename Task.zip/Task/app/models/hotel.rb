class Hotel < ActiveRecord::Base
  validates :title, :description, :photo, :breakfast, :star, :price, :adress, presence: true


  validates :price, numericality: {greater_than_or_equal_to: 0.01}

  validates :title, uniqueness: true
  validates :photo, allow_blank: true, format: {
      with: %r{\.(gif|jpg|png)\Z}i,
      message: 'must be a URL for GIF, JPG or PNG image.'
  }

  validates :title, length: {minimum: 10}
end
